#!/usr/bin/env sh

date="$(date +'%d/%m/%Y %H:%M')"
echo "^c$COL_BLANC^$date ^c#444444^"
